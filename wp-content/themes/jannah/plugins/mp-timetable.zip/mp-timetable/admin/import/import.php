<?php

if ( current_user_can('import') ) { ?>
	<h3><?php _e('Import', 'mp-timetable') ?></h3><?php
	wp_import_upload_form('admin.php?import=mptt-importer&amp;step=1');
}
