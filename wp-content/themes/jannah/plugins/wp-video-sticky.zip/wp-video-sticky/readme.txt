=== Wordpress Video Sticky ===
Contributors: rajkakadiya
Donate link: http://geekwebsolution.com/
Tags:draggable, fixed video, floating video, scrolling, sticky video wp, draggable video player
Requires PHP: 5.2.4
Requires at least: 3.0.1
Tested up to: 4.9.5
Stable tag: 1.2

Wordpress Video Sticky plugin for wordpress allows to make Video sticky on scroll down or up while video is playing, easily to add embed video ( Youtube, Vimeo or Self-Hosted MP4s)  on post, page or any custom post type, Move possition of video to drag button after sticky, the video will float to the bottom-right, bottom-left, top-right, top-left on mobile and desktop.

== Description ==

Wordpress Video Sticky plugin for wordpress allows to make Video sticky on scroll down or up while video is playing, easily to add embed video ( Youtube, Vimeo or Self-Hosted MP4s)  on post, page or any custom post type, Move possition of video to drag button after sticky, the video will float to the bottom-right, bottom-left, top-right, top-left on mobile and desktop.

With this plugin you can use video links from YouTube, Vimeo and Self-Hosted MP4s as your video source. Once you have the link for the video you want to use simply paste it into add video shortcode popup in post. 

Your video will float along the left or right side of the browser window as the reader scrolls the content, so both the video and your marketing message stay in focus.

Video will be sticky after scroll up or down if video is playing (not pause) same like facebook.

Setting page allow to select sticky video position, sticky video size, vertical and horizontal margin etc

[Live Demo](http://wpplugins.geekwebsolution.com/wordpress-video-sticky-demo/ "Wordpress Video Sticky Demo")

**Plugin Features**

* Sticky/pinned floating video on page Scroll 
* Supported multiple videos in single page 
* Draggable - move video position after sticky
* Easy setup and minimal configuration
* Create Shortcode button on post and page
* Options panel for easy customizations
* Supported many video hosting platforms like YouTube, Vimeo, WordPress Media Library Etc
 
**Preview**
[youtube https://youtu.be/_-odCeMO-tQ]

== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

After Plug-in Active go to Setting-> WP Video Sticky.

== Screenshots ==
1. Add Shortcode popup
2. Setting page
3. Preview page


== Changelog ==
= 1.1 =
* added Draggable video functionality
* fixed bug
* update setting page options and UI

= 1.0 =
* Initial release

= 1.1 =
* add advance option

= 1.2 =
* fix responsive issue
